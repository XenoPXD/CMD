import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Solution {

	private static Pattern patternQuaternion = Pattern.compile("(\\([ijk\\+\\-0-9]*\\))");
//	private static Pattern patternTerme = Pattern.compile("(\\+|\\-)(\\d*)([ijk]*)");
    private static Matcher matcher;
    private static List<Quaternion> listeQuaternion = new ArrayList<Quaternion>();
//    private static Quaternion q1,q2;
    
    
    public static void main(String args[]) {
    	
    	if ((args.length == 0 || "-h".equals(args[0]))) {
    		help();
    	} else {
    		quaternions(concatArgs(args));
    	}
        
    }
    
    private static String concatArgs(String[] args) {
    	String value = "";
		for (int i = 0; i < args.length; i++) {
			value += args[i];
		}
		return value.replaceAll(" ", "");
	}
    
    public static void quaternions(String value) {
		
    	// Split des quaternions
        matcher = patternQuaternion.matcher(value);
        
        while(matcher.find()) {
        	String quaternionLibelle = "";
        	quaternionLibelle += matcher.group().replaceAll("\\(|\\)", "");
        	if (!quaternionLibelle.substring(0,1).equals("-")) {
        		quaternionLibelle = "+" + quaternionLibelle;
        	}
        	listeQuaternion.add(new Quaternion(quaternionLibelle));
        }
        
        // Multiplier quaternion
        
        for (int i = 1; i < listeQuaternion.size(); ++i) {
        	listeQuaternion.get(0).multiplier(listeQuaternion.get(i));
        }
        
        //return listeQuaternion.get(0).getLibelleIHM();
    	System.out.println(listeQuaternion.get(0).getLibelleIHM());
    	
	}
 
    private static void help() {
    	System.out.println("usage: java -jar quaternions-multiplication.jar <expression>");
    	System.out.println("");
    	System.out.println("example\texpression");
    	System.out.println("small\t(i+j)(k)");
    	System.out.println("medium\t(i+j+20)(j-9)");
    	System.out.println("large\t(10i)(10j-k+1)(-99i+j-10k+7)(4)");
    	System.out.println("giant\t(i+j+k+1)(i+2j+4k+8)(i+3j+9k+27)(i+j+8k+8)(i-j+k-10)(99i-j+k-1)(k)(j)(i)(3)");
	}
    
 
    
}