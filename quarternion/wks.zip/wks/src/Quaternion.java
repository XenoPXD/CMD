import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Quaternion {

	private static Pattern patternTerme = Pattern.compile("(\\+|\\-)(\\d*)([ijk]*)");
	private Matcher matcher;
	private String libelle = "";
	private List<Terme> listeTermes = new ArrayList<Terme>();
	private static Map<String, Terme> produitsSymboles = new HashMap<String, Terme>();
	
	static {
		produitsSymboles.put("ii", new Terme("-", 1, ""));
		produitsSymboles.put("jj", new Terme("-", 1, ""));
		produitsSymboles.put("kk", new Terme("-", 1, ""));
		produitsSymboles.put("ij", new Terme("+", 1, "k"));
		produitsSymboles.put("jk", new Terme("+", 1, "i"));
		produitsSymboles.put("ki", new Terme("+", 1, "j"));
		produitsSymboles.put("ji", new Terme("-", 1, "k"));
		produitsSymboles.put("kj", new Terme("-", 1, "i"));
		produitsSymboles.put("ik", new Terme("-", 1, "j"));
	}
	
	public Quaternion() {
		super();
	}
	
	public Quaternion(String libelle) {
		super();
		this.libelle = libelle;
		splitTermes();
	}

	public void multiplier(Quaternion quaternion) {
    	
//		System.err.println("Quaternion multiplier : " + this.getLibelle()  + " * " + quaternion.getLibelle());
    	distribuer(quaternion);
//    	System.err.println("Quaternion distribuer : " + this.getLibelle());
    	remplacerProduit();
//    	System.err.println("Quaternion remplacerProduit : " + this.getLibelle());
    	reduire();
//    	System.err.println("Quaternion reduire : " + this.getLibelle());
    	
    }
	
	public void reduire() {

		List<Terme> listeV = new ArrayList<Terme>();
		List<Terme> listeI = new ArrayList<Terme>();
		List<Terme> listeJ = new ArrayList<Terme>();
		List<Terme> listeK = new ArrayList<Terme>();
		for (Terme terme : this.getListeTermes()) {
			if (terme.getVariable().equals(""))
				listeV.add(terme);
			if (terme.getVariable().equals("i"))
				listeI.add(terme);
			if (terme.getVariable().equals("j"))
				listeJ.add(terme);
			if (terme.getVariable().equals("k"))
				listeK.add(terme);
		}

		Terme termeI = additionner(listeI, "i");
//		System.out.println("termeI : " + termeI.getLibelle());

		Terme termeJ = additionner(listeJ, "j");
//		System.out.println("termeJ : " + termeJ.getLibelle());

		Terme termeK = additionner(listeK, "k");
//		System.out.println("termeK : " + termeK.getLibelle());

		Terme termeV = additionner(listeV, "");
//		System.out.println("termeV : " + termeV.getLibelle());

		this.getListeTermes().clear();
		this.getListeTermes().add(termeI);
		this.getListeTermes().add(termeJ);
		this.getListeTermes().add(termeK);
		this.getListeTermes().add(termeV);

//		System.out.println("finalQuaternion : " + this.getLibelle());
//		System.out.println("finalQuaternion : " + this.getLibelleIHM());
		

	}
	
	public static Terme additionner(List<Terme> listeQuaternion, String variable) {

		Terme newTerme = new Terme("+", 0, variable);
		if (listeQuaternion.size() >= 1) {
			newTerme = listeQuaternion.get(0);
		}
		if (listeQuaternion.size() >= 2) {
			for (int i = 1; i < listeQuaternion.size(); ++i) {

				Terme terme = listeQuaternion.get(i);

				// Calcul signe et coef et variable
				int s1 = Integer.parseInt(newTerme.getSigne() + newTerme.getCoef());
				int s2 = Integer.parseInt(terme.getSigne() + terme.getCoef());
				int rs = s1 + s2;
				String rStr = String.valueOf(rs);
				if (!rStr.substring(0, 1).equals("-"))
					rStr = "+" + rStr;
				newTerme.setSigne(rStr.replaceAll("[0-9]", ""));
				newTerme.setCoef(Integer.parseInt(rStr.substring(1)));

			}
		}
		return newTerme;

	}
	
	public void remplacerProduit() {
		
//		System.err.println("quaternion Avant produit : " + this.getLibelle());
		
		for (Terme terme : this.getListeTermes()) {
			
			for(Entry<String, Terme> entry : getProduitsSymboles().entrySet()) {
				String cle = entry .getKey();
				Terme termeProduit = entry .getValue();
				
				if (terme.getVariable().equals(cle)) {
//					System.out.println("produit du terme : " + cle);
					// Calcul signe
	    			int s1 = Integer.parseInt(terme.getSigne()+"1");
	    			int s2 = Integer.parseInt(termeProduit.getSigne()+"1");
	    			int rs = s1*s2;
	    			String rStr = String.valueOf(rs);
	    			if (!rStr.substring(0,1).equals("-")) rStr = "+"+rStr;
	    			terme.setSigne(rStr.replaceAll("[0-9]", ""));
					
	    			// Calcul coef
	    			int coef1 = terme.getCoef();
	    			int coef2 = termeProduit.getCoef();
	    			terme.setCoef(coef1*coef2);
	    			
	    			// Calcul variables
	    			terme.setVariable(termeProduit.getVariable());
	    			
//	    			System.out.println("new terme produit : " + terme.getLibelle());
				}
				
			}
			
			
		}
		
//		System.err.println("quaternion Avant produit : " + this.getLibelle());
	}
	
	private void distribuer(Quaternion q2) {
    	
    	Quaternion quaternion = new Quaternion();
    	for (Terme terme1 : this.getListeTermes()) {
    		for (Terme terme2 : q2.getListeTermes()) {
    			
    			Terme terme = new Terme();
    			// Calcul signe
    			int s1 = Integer.parseInt(terme1.getSigne()+"1");
    			int s2 = Integer.parseInt(terme2.getSigne()+"1");
    			int rs = s1*s2;
    			String rStr = String.valueOf(rs);
    			if (!rStr.substring(0,1).equals("-")) rStr = "+"+rStr;
    			terme.setSigne(rStr.replaceAll("[0-9]", ""));
    			
    			// Calcul coef
    			int coef1 = terme1.getCoef();
    			int coef2 = terme2.getCoef();
    			terme.setCoef(coef1*coef2);
    			
    			// Calcul variables
    			terme.setVariable(terme1.getVariable()+terme2.getVariable());
//    			System.out.println("new terme : " + terme.getLibelle());
    			quaternion.getListeTermes().add(terme);
    			
    		}
		}
    	
    	this.setListeTermes(quaternion.getListeTermes());
    	
    }

	private void splitTermes() {
		// Split des termes
//		System.out.println("Quaternion : " + this.libelle);
		matcher = patternTerme.matcher(this.libelle);
		while (matcher.find()) {

			Terme terme = new Terme();
			for (int i = 0; i <= matcher.groupCount(); i++) {
				// affichage de la sous-cha�ne captur�e
//				System.out.println("Groupe " + i + " : " + matcher.group(i));
				if (i == 0)
					terme.setLibelle(matcher.group(i));
				if (i == 1)
					terme.setSigne(matcher.group(i));

				if (i == 2) {
					if (matcher.group(i).isEmpty()) {
						terme.setCoef(1);
					} else {
						terme.setCoef(Integer.parseInt(matcher.group(i)));
					}
				}

				if (i == 3)
					terme.setVariable(matcher.group(i));

			}
			listeTermes.add(terme);
		}
	}
	
	
	public String getLibelle() {
		String l = "";
		for (Terme terme : listeTermes) {
			l += terme.getLibelle();
		}
		
		return l;
	}

	public String getLibelleIHM() {
		String l = "";
		Terme terme = listeTermes.get(0);
		if (terme.getCoef() != 0) {
			if (!terme.getSigne().equals("+"))
				l += terme.getSigne();
			if (terme.getCoef() == 1 && !"".equals(terme.getVariable().trim())) {
				// l += coef;
			} else {
				l += terme.getCoef();
			}
			l += terme.getVariable();
		}
		for (int i=1; i < listeTermes.size(); ++i) {
			
			Terme termeN = listeTermes.get(i);
			
			l += termeN.getLibelleIHM();
		}
		
		return l;
	}
	
	public void setLibelle(String libelle) {
		this.libelle = libelle;
		splitTermes();
	}

	
	


	public static Map<String, Terme> getProduitsSymboles() {
		return produitsSymboles;
	}


	public static void setProduitsSymboles(Map<String, Terme> produitsSymboles) {
		Quaternion.produitsSymboles = produitsSymboles;
	}


	public List<Terme> getListeTermes() {
		return listeTermes;
	}

	public void setListeTermes(List<Terme> listeTermes) {
		this.listeTermes = listeTermes;
	}

	
	
	
}
