import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class Terme {

	
	private String libelle = "";
	private String variable = "";
	private String signe = "";
	private int coef = 1;
	private List<Character> listeVariables = new ArrayList<Character>();
	
	public Terme() {
	}	
	
	public Terme(String signe, int coef, String variable) {
		super();
		this.variable = variable;
		this.signe = signe;
		this.coef = coef;
	}

	public void updateLibelle() {
		libelle = signe + coef + variable;
	}
	
	public String getVariable() {
		return variable;
	}
	public void setVariable(String variable) {
		this.variable = variable;
	}
	public List<Character> getListeVariables() {
		return listeVariables;
	}
	public void setListeVariables(List<Character> listeVariables) {
		this.listeVariables = listeVariables;
	}
	public String getLibelle() {
		return signe + coef + variable;
	}
	
	public String getLibelleIHM() {
		String l ="";
		if (coef != 0) {
			l = signe;
			if (coef == 1 && !"".equals(variable.trim())) {
				// l += coef;
			} else {
				l += coef;
			}
			l += variable;
		}
		return l;
	}
	
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getSigne() {
		return signe;
	}
	public void setSigne(String signe) {
		this.signe = signe;
	}
	public int getCoef() {
		return coef;
	}
	public void setCoef(int coef) {
		this.coef = coef;
	}
	
	public void asList(final String string) {
		listeVariables =  new AbstractList<Character>() {
	       public int size() { return string.length(); }
	       public Character get(int index) { return string.charAt(index); }
	    };
	}
	
}
